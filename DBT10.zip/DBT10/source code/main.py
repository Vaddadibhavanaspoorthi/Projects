import datetime
from datetime import timedelta
from itertools import count
from dns.e164 import query
from flask import Flask, request, render_template, redirect, session
import pymysql
from pyexpat.errors import messages
conn = pymysql.connect(host="localhost",user="root",password="Bhavana@123",database="Studentmeeting")
cursor = conn.cursor()
app = Flask(__name__)
app.secret_key="hello"
import os
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
PROFILES_PATH = APP_ROOT + "/static/picture"
@app.route("/")
def index():
    return render_template("index.html")
@app.route("/admin_login")
def admin_login():
    return render_template("admin_login.html")

admin_username = "admin"
admin_password = "admin"

@app.route("/admin_login_action",methods=["post"])
def admin_login_action():
    username = request.form.get("username")
    password = request.form.get("password")
    if(username==admin_username and password==admin_password):
        session['role']='admin'
        return render_template("admin_home.html")
    else:
        return render_template("message.html",message="Invalid credentials")
@app.route("/admin_home")
def admin_home():
    return render_template("admin_home.html")


@app.route("/departments")
def departments():
    cursor.execute("select * from Departments")
    departments = cursor.fetchall()
    return render_template("departments.html", departments=departments)
@app.route("/add_departments_action",methods=['POST'])
def add_departments_action():
    department_name = request.form.get("department_name")
    count = cursor.execute("select * from departments where department_name='"+str(department_name)+"'")
    if count > 0:
        return render_template("admin_message.html",message="department exists")
    else:
        cursor.execute("insert into Departments(department_name) values('"+str(department_name)+"')")
    conn.commit()
    return render_template("admin_message.html", message= "Department added successfully")
@app.route("/view_departments")
def view_departments():
     cursor.execute("select * from Departments")
     departments = cursor.fetchall()
     return redirect("/departments.html",departments=departments)

@app.route("/student_login")
def student_login():
    return render_template("student_login.html")
@app.route("/student_login_action", methods=["POST"])
def student_login_action():
    email = request.form.get("email")
    password = request.form.get("password")

    count = cursor.execute("select * from students where email='" + str(email) + "' and password='" + str(password) + "'")

    if count > 0:
        students = cursor.fetchall()
        session['student_id'] = students[0][0]
        session['role'] = "student"
        return render_template("student_home.html")
    else:
        return render_template("message.html", message="Invalid login credentials")
@app.route("/student_registration")
def student_registration():
    cursor.execute("select * from departments")
    departments = cursor.fetchall()
    return render_template("student_registration.html", departments=departments)
@app.route("/student_registration_action", methods=["POST"])
def student_registration_action():
    name = request.form.get("name")
    email = request.form.get("email")
    password = request.form.get("password")
    crn = request.form.get("crn")
    phone = request.form.get("phone")
    address = request.form.get("address")

    count = cursor.execute("select * from students where email='" + str(email) + "'")
    if count > 0:
        return render_template("message.html", message="Email already exists")

    count = cursor.execute("insert into students(name,email,password,crn,phone,address) values('" + str(name) + "','" + str(email) + "','" + str(password) + "','" + str(crn) + "','" + str(phone) + "','" + str(address) + "')")
    conn.commit()

    return render_template("message.html", message="Student registered successfully")

@app.route("/student_home")
def student_home():
    return render_template("student_home.html")

@app.route("/instructor_login")
def instructor_login():
    return render_template("instructor_login.html")

@app.route("/instructor_login_action", methods=["POST"])
def instructor_login_action():
    email = request.form.get("email")
    password = request.form.get("password")

    count = cursor.execute("select * from instructors where email='" + str(email) + "' and password='" + str(password) + "'")

    if count > 0:
        instructors = cursor.fetchall()
        session["instructor_id"] = instructors[0][0]
        session["role"] = "instructor"
        return render_template("instructor_home.html")
    else:
        return render_template("message.html", message="Invalid login credentials")

@app.route("/instructor_registration")
def instructor_registration():
    cursor.execute("select * from departments")
    departments = cursor.fetchall()
    return render_template("instructor_registration.html", departments=departments)

@app.route("/instructor_registration_action", methods=["POST"])
def instructor_registration_action():
    name = request.form.get("name")
    email = request.form.get("email")
    phone = request.form.get("phone")
    department_id = request.form.get("department_id")
    experience = request.form.get("experience")
    password = request.form.get("password")
    picture = request.files.get("picture")
    path = PROFILES_PATH + "/" + picture.filename
    picture.save(path)

    count = cursor.execute("select * from instructors where email='" + str(email) + "'")
    if count > 0:
        return render_template("message.html", message="Email already exists")

    count = cursor.execute("insert into instructors(name,email,phone,password,experience,department_id,picture)values('" + str(name) + "','" + str(email) + "','" + str(phone) + "','" + str(password) + "','" + str(experience) + "','" + str(department_id) + "','"+str(picture.filename)+"')")

    conn.commit()

    return render_template("message.html", message="Instructor registered successfully")

@app.route("/instructor_home")
def instructor_home():
    return render_template("instructor_home.html")

@app.route("/my_profile")
def my_profile():
    instructor_id = session.get("instructor_id")
    cursor.execute("select * from instructors where instructor_id= '"+str(instructor_id)+"'")
    instructors = cursor.fetchall()
    department_id = instructors[0][6]
    cursor.execute("select department_name from Departments where department_id= '" + str(department_id) + "'")
    department = cursor.fetchone()
    cursor.execute("select day, start_time, end_time from instructors where instructor_id='"+str(instructor_id)+"'")
    timings = cursor.fetchall()
    return render_template("instructor_profile.html", instructors=instructors, department=department,get_department_id_by_instructor=get_department_id_by_instructor,timings=timings)


def get_department_id_by_instructor(department_id):
    cursor.execute("select department_name from Departments where department_id='"+str(department_id)+"'")
    row = cursor.fetchone()
    if row:
        return row[0]
    return ""

@app.route("/add_timings")
def add_timings():

    return render_template("add_timings.html")



@app.route("/add_timings_action", methods=['POST'])
def add_timings_action():
    instructor_id = session.get("instructor_id")

    day = request.form.get("day")
    start_time = request.form.get("start_time")
    end_time = request.form.get("end_time")
    cursor.execute("update instructors set day='"+str(day)+"', start_time='"+str(start_time)+"', end_time='"+(end_time)+"' where instructor_id='"+str(instructor_id)+"'")
    conn.commit()
    start_time2 = datetime.datetime.strptime(start_time,"%H:%M")
    end_time2 = datetime.datetime.strptime(end_time,"%H:%M")
    while start_time2 < end_time2:
        nxt_slot = start_time2+timedelta(minutes=30)
        cursor.execute("insert into time_slots (instructor_id,start_time,end_time,day)values('"+str(instructor_id)+"','"+str(start_time2)+"','"+str(nxt_slot)+"','"+str(day)+"')")
        start_time2 = nxt_slot
    conn.commit()
    return redirect("/my_profile")


@app.route("/view_slots")
def view_slots():
    instructor_id = session.get("instructor_id")
    day = request.args.get("day")
    cursor.execute("select start_time,end_time from time_slots where instructor_id='"+str(instructor_id)+"' and day='"+str(day)+"'")
    slots = cursor.fetchall()
    return render_template("view_slots.html", slots=slots, day=day)


@app.route("/instructors")
def instructors():
    section_id = request.args.get("section_id")
    search_name = request.args.get("search_name")
    sql = ""
    if search_name==None:
        search_name=""
    if search_name!="":
        sql= "select * from instructors where  name like  '%"+str(search_name)+"%' or phone like  '%"+str(search_name)+"%' where instructor_id in (select instructor_id from sections where section_id='"+str(section_id)+"')"
    else:
        sql= "select * from instructors where instructor_id in (select instructor_id from sections where section_id='"+str(section_id)+"')"

    cursor.execute(sql)
    instructors = cursor.fetchall()
    return render_template("instructors.html",instructors=instructors,get_department_by_department_id=get_department_by_department_id)


def get_department_by_department_id(department_id):
    cursor.execute("select * from departments where department_id='"+str(department_id)+"'")
    departments = cursor.fetchone()
    return departments


@app.route("/book_slot")
def book_slot():
    instructor_id = request.args.get("instructor_id")
    cursor.execute("select * from time_slots where instructor_id='"+str(instructor_id)+"'")
    time_slots=cursor.fetchall()
    return render_template("book_slots.html",time_slots=time_slots,get_is_slot_booked=get_is_slot_booked
                           )
def get_is_slot_booked(time_slot_id):
    count = cursor.execute("select * from meetings where status='Scheduled' and time_slot_id='"+str(time_slot_id)+"'")

    return count

@app.route("/book_slot_action",methods=['post'])
def book_slot_action():
    time_slot_id = request.form.get("time_slot_id")
    return render_template("book_slot_action.html",time_slot_id=time_slot_id)


@app.route("/save_meeting", methods=['POST'])
def save_meeting():
    student_id = session.get("student_id")
    time_slot_id = request.form.get("time_slot_id")
    meeting_type = request.form.get("meeting_type")
    meeting_mode = request.form.get("meeting_mode")
    meeting_date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    status = "Scheduled"
    cursor.execute("insert into meetings(student_id, time_slot_id, meeting_type, meeting_mode, meeting_date, status)values('"+str(student_id)+"','"+str(time_slot_id)+"','"+str(meeting_type)+"','"+str(meeting_mode)+"','"+str(meeting_date)+"','"+str(status)+"')")
    conn.commit()

    return render_template("message2.html", message="Meeting scheduled successfully")

@app.route("/schedules")
def schedules():
    sql= ""
    if session['role']=='instructor':
       sql = ("select * from meetings where time_slot_id in (select time_slot_id from time_slots where instructor_id='"+str(session['instructor_id'])+"')")

    elif session['role']=='student':
        sql = ("select * from meetings where student_id='" + str(session['student_id']) + "'")
    elif session['role'] == 'admin':
        sql = "select * from meetings"
    cursor.execute(sql)
    meetings = cursor.fetchall()
    meetings= list(meetings)
    meetings.reverse()
    return render_template("schedules.html",get_queries_by_meeting_and_student=get_queries_by_meeting_and_student,meetings=meetings,get_timeslot_by_time_slot_id=get_timeslot_by_time_slot_id,get_instructor_by_instructor_id=get_instructor_by_instructor_id,get_student_by_student_id=get_student_by_student_id)


def get_timeslot_by_time_slot_id(time_slot_id):
    cursor.execute("select * from time_slots where time_slot_id='"+str(time_slot_id)+"'")
    time_slot = cursor.fetchone()
    return time_slot

def get_instructor_by_instructor_id(instructor_id):
    cursor.execute("select * from instructors where instructor_id='"+str(instructor_id)+"'")
    instructor =  cursor.fetchone()
    return instructor

def get_student_by_student_id(student_id):
    cursor.execute("select * from students where student_id='"+str(student_id)+"'")
    student =  cursor.fetchone()
    return student

@app.route("/queries")
def queries():
    meeting_id = request.args.get("meeting_id")
    student_id = session.get("student_id")
    return render_template("queries.html",meeting_id=meeting_id,student_id=student_id)


@app.route("/queries_action", methods=["POST"])
def queries_action():
    meeting_id = request.form.get("meeting_id")
    student_id = request.form.get("student_id")
    query_text = request.form.get("query_text")
    cursor.execute("insert into queries(meeting_id,student_id,query_text,query_status)values('"+str(meeting_id)+"','"+str(student_id)+"','"+str(query_text)+"','Pending')")
    conn.commit()
    return render_template("message2.html", message="Query submitted successfully!")

def get_queries_by_meeting_and_student(meeting_id, student_id):
    cursor.execute("SELECT * FROM queries WHERE meeting_id=%s AND student_id=%s ORDER BY query_id DESC", (meeting_id, student_id))
    return cursor.fetchall()


@app.route("/view_queries")
def view_queries():
    return 0

@app.route("/reply_query_action", methods=["POST"])
def reply_query_action():
    query_id = request.form.get("query_id")
    reply_text = request.form.get("reply_text")

    cursor.execute("UPDATE queries SET response_text=%s, query_status='Resolved' WHERE query_id=%s", (reply_text, query_id))
    conn.commit()

    return redirect("/schedules")


@app.route("/add_section")
def add_section():
    cursor.execute("select instructor_id, name, email from instructors")
    instructors = cursor.fetchall()
    cursor.execute("select * from sections")
    sections = cursor.fetchall()
    return render_template("sections.html", instructors=instructors,sections=sections,get_instructor_by_instructor_id=get_instructor_by_instructor_id)


@app.route("/add_section_action", methods=["POST"])
def add_section_action():
    crn = request.form.get("crn")
    section_name = request.form.get("section_name")
    number_of_students = request.form.get("number_of_students")
    instructor_id = request.form.get("instructor_id")
    count = cursor.execute("select  * from sections where section_name='"+str(section_name)+"' or crn='"+str(crn)+"'")
    if count>0:
        return render_template("admin_message.html",message="Duplicate Section Adding")
    cursor.execute("insert into sections(crn,number_of_students,instructor_id,section_name)values('"+str(crn)+"','"+str(number_of_students)+"','"+str(instructor_id)+"','"+str(section_name)+"')")
    conn.commit()
    return redirect("/add_section")


@app.route("/view_sections")
def view_sections():
    sql = "select * from sections"
    cursor.execute(sql)
    sections = cursor.fetchall()
    return render_template("view_sections.html",get_isSectionEnrolled=get_isSectionEnrolled,sections=sections,get_instructor_by_instructor_id=get_instructor_by_instructor_id)


@app.route("/enroll_section",methods=['post'])
def enroll_section():
    section_id =  request.form.get("section_id")
    cursor.execute("insert into section_students (section_id,student_id) values ('"+str(section_id)+"','"+str(session['student_id'])+"')")
    conn.commit()
    return redirect("/view_sections")

def get_isSectionEnrolled(section_id):
    count=cursor.execute("select * from section_students where section_id='"+str(section_id)+"' and student_id='"+str(session['student_id'])+"'")
    print(count)

    return count

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

@app.route("/save_recording", methods=["POST"])
def save_recording():
    meeting_id = request.form["meeting_id"]
    file = request.files["record_file"]

    filename = f"record_{meeting_id}.webm"  # only filename stored in DB
    save_path = os.path.join("static/recordings", filename)
    file.save(save_path)

    cursor.execute("UPDATE meetings SET meet_recordings=%s WHERE meeting_id=%s",
                   (filename, meeting_id))
    conn.commit()

    return redirect("/schedules")
app.run(debug=True)