drop database Studentmeeting;
create database Studentmeeting;
use Studentmeeting;
create table admin(
username varchar(255),
password varchar(255)
);
create table Departments (
    department_id int auto_increment primary key,
    department_name varchar(255) NOT NULL
);
create table Students (
    student_id int auto_increment primary key,
    name varchar(255) not null,
    email varchar(255) unique not null,
    password varchar(255) not null,
    crn varchar(255),
    phone varchar(15),
    address varchar(255)
);
create table instructors(
    instructor_id int auto_increment primary key,
    name varchar(255) not null,
    email varchar(255) unique not null,
    phone varchar(255),
    password varchar(255) not null,
    experience int,
    department_id int,
    picture varchar(255),
    day varchar(255),
    start_time varchar(255),
    end_time varchar(255),
    foreign key (department_id) references Departments(department_id)
);
create table sections(
section_id int auto_increment primary key,
crn varchar(255),
section_name varchar(255),
number_of_students varchar(255),
instructor_id int,
student_id int,
foreign key (instructor_id) references instructors(instructor_id),
FOREIGN KEY (student_id) REFERENCES Students(student_id)
);

create table section_students(
section_student_id int auto_increment primary key,
section_id int,
student_id int,
foreign key (section_id) references sections(section_id),
FOREIGN KEY (student_id) REFERENCES Students(student_id)
);


create table time_slots (
    time_slot_id int auto_increment primary key,
    instructor_id int not null,
    start_time time not null,
    end_time time not null,
    day varchar(255) not null,
    foreign key (instructor_id) references instructors(instructor_id)
);
CREATE TABLE Meetings (
    meeting_id INT AUTO_INCREMENT PRIMARY KEY,
    meeting_date DATE NOT NULL,
    time_slot_id INT,
    student_id INT,
    meeting_mode varchar(255) NOT NULL,
    meeting_type varchar(255) NOT NULL,
    status varchar(255),
    FOREIGN KEY (time_slot_id) REFERENCES time_slots(time_slot_id),
    FOREIGN KEY (student_id) REFERENCES Students(student_id),
    meet_recordings varchar(455)
);


CREATE TABLE Queries (
    query_id INT AUTO_INCREMENT PRIMARY KEY,
    meeting_id INT NOT NULL,
    student_id int not null,
    query_text varchar(255),
    response_text varchar(255),
    query_status varchar(255),
    meet_recordings varchar(255),
    FOREIGN KEY (meeting_id) REFERENCES Meetings(meeting_id),
	FOREIGN KEY (student_id) REFERENCES Students(student_id)
);
