import datetime

from flask import Flask, request, render_template, redirect, session
import pymongo
from bson import ObjectId
my_client=pymongo.MongoClient("mongodb://localhost:27017")
my_database=my_client["DoctorAppointmentBooking2"]
admin_collection = my_database["admin"]
hospital_collection = my_database["hospital"]
doctor_collection = my_database["doctor"]
patient_collection = my_database["patient"]
locations_collection = my_database["locations"]
schedule_collection = my_database["doctor_schedules"]
slots_collection = my_database["slots"]
appointment_collection = my_database["appointments"]
payments_collection = my_database["payments"]
prescription_collection = my_database["prescriptions"]

app=Flask(__name__)
app.secret_key="hello"

admin_username="admin"
admin_password="admin"

count=admin_collection.count_documents({"username":admin_username,"password":admin_password})
if count==0:
    admin_collection.insert_one({"username":admin_username,"password":admin_password})

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/admin_login")
def admin_login():
    return render_template("admin_login.html")

@app.route("/admin_login_action", methods=['POST'])
def admin_login_action():
    username = request.form.get("username")
    password = request.form.get("password")
    if username == admin_username and password == admin_password:
        session["role"] = "admin"
        return redirect("/admin_home")
    else:
        return render_template("message1.html", message="Invalid Login Details")

@app.route("/admin_home")
def admin_home():
    if session.get("role") != "admin":
        return redirect("/admin_login")
    return render_template("admin_home.html")


@app.route("/view_hospitals")
def view_hospitals():
    hospitals = list(hospital_collection.find())
    return render_template("view_hospitals.html", hospitals=hospitals)

@app.route("/view_doctors")
def view_doctors():
    if session.get("role") != "admin":
        return redirect("/admin_login")
    doctors = list(doctor_collection.find())
    return render_template("view_doctors.html", doctors=doctors)


@app.route("/add_hospitals", methods=["GET", "POST"])
def add_hospitals():
    locations = list(locations_collection.find())
    if request.method == "POST":
        hospital_name = request.form.get("hospital_name")
        email = request.form.get("email")
        phone = request.form.get("phone")
        password = request.form.get("password")
        address = request.form.get("address")
        city = request.form.get("city")
        state = request.form.get("state")
        count = hospital_collection.count_documents({"$or": [{"email": email}, {"phone": phone}]})
        if count:
            if hospital_collection.count_documents({"email": email}):
                return render_template("message1.html", message="Email already registered!")
            else:
                return render_template("message1.html", message="Phone number already registered!")
        data = {"hospital_name": hospital_name,"email": email,"phone": phone,"password": password,"address": address, "city": city,"state": state}
        hospital_collection.insert_one(data)
        return render_template("message1.html", message="Hospital Added Successfully!")

    return render_template("add_hospitals.html", locations=locations)



@app.route("/hospital_login")
def hospital_login():
    return render_template("hospital_login.html")

@app.route("/hospital_login_action", methods=['POST'])
def hospital_login_action():
    email = request.form.get("email")
    password = request.form.get("password")
    hospital = hospital_collection.find_one({"email": email, "password": password})
    if hospital:
        session["role"] = "hospital"
        session["hospital_id"] = str(hospital["_id"])
        return render_template("/hospital_home.html")
    else:
        return render_template("message1.html", message="Invalid Login Details!")


@app.route("/hospital_home")
def hospital_home():
    return render_template("hospital_home.html")



@app.route("/doctor_register")
def doctor_register():
    return render_template("doctor_register.html")

@app.route("/doctor_register_action", methods=['POST'])
def doctor_register_action():
        name = request.form.get("name")
        email = request.form.get("email")
        phone = request.form.get("phone")
        password = request.form.get("password")
        specialization = request.form.get("specialization")
        experience = request.form.get("experience")
        count = doctor_collection.count_documents({"$or": [{"email": email}, {"phone": phone}]})
        if count:
            if doctor_collection.count_documents({"email": email}):
                return render_template("message1.html", message="Email already registered!")
            else:
                return render_template("message1.html", message="Phone number already registered!")

        data = {
            "name": name,
            "email": email,
            "phone": phone,
            "password": password,
            "specialization": specialization,
            "experience": experience,
            "status": "Pending"
        }

        doctor_collection.insert_one(data)
        return render_template("message1.html", message="Doctor Registered Successfully!")


@app.route("/verify_doctor", methods=["POST"])
def verify_doctor():
    if session.get("role") != "admin":
        return redirect("/admin_login")
    doctor_id = request.form.get("doctor_id")
    doctor_collection.update_one({"_id": ObjectId(doctor_id)},{"$set": {"status": "Verified"}})
    return redirect("/view_doctors")


@app.route("/doctor_login")
def doctor_login():
    return render_template("doctor_login.html")

@app.route("/doctor_login_action", methods=['POST'])
def doctor_login_action():
    email = request.form.get("email")
    password = request.form.get("password")

    doctor = doctor_collection.find_one({"email": email, "password": password})
    if not doctor:
        return render_template("message1.html", message="Invalid Doctor Login")

    if doctor["status"] == "Pending":
        return render_template("message1.html", message="Not verified by admin yet!")

    session["role"] = "doctor"
    session["doctor_id"] = str(doctor["_id"])
    return redirect("/doctor_home")

@app.route("/doctor_home")
def doctor_home():
    if session.get("role") != "doctor":
        return redirect("/doctor_login")
    return render_template("doctor_home.html")


@app.route("/patient_register")
def patient_register():
    return render_template("patient_register.html")

@app.route("/patient_register_action", methods=['POST'])
def patient_register_action():
    name = request.form.get("name")
    email = request.form.get("email")
    phone = request.form.get("phone")
    gender = request.form.get("gender")
    address = request.form.get("address")
    password = request.form.get("password")
    city = request.form.get("city")
    state = request.form.get("state")

    # Check duplicates (email or phone)
    existing = patient_collection.find_one({"$or": [{"email": email}, {"phone": phone}]})

    if existing:
        if existing.get("email") == email:
            return render_template("message.html", message="Email already registered!")
        if existing.get("phone") == phone:
            return render_template("message.html", message="Phone number already registered!")
    patient_collection.insert_one({
        "name": name,
        "email": email,
        "phone": phone,
        "password": password,
        "address": address,
        "city": city,
        "gender": gender,
        "state": state
    })

    return render_template("message1.html", message="Patient Registered Successfully!")

@app.route("/patient_login")
def patient_login():
    return render_template("patient_login.html")

@app.route("/patient_login_action", methods=['POST'])
def patient_login_action():
    email = request.form.get("email")
    password = request.form.get("password")
    patient = patient_collection.find_one({"email": email, "password": password})
    if patient:
        session["role"] = "patient"
        session["patient_id"] = str(patient["_id"])
        return render_template("patient_home.html")
    else:
        return render_template("message1.html", message="Invalid Login Details!")


@app.route("/patient_home")
def patient_home():
    return render_template("patient_home.html")

@app.route('/locations')
def locations():
    message = request.args.get("message")
    if message is None:
        message = ""
    locations = list(locations_collection.find())
    return render_template("locations.html", locations=locations, message=message)

@app.route("/add_location_action", methods=['POST'])
def add_location_action():
    location_name = request.form.get("location_name")
    count = locations_collection.count_documents({"location_name": location_name})
    if count > 0:
        return redirect("/locations?message=Location already exists")
    locations_collection.insert_one({"location_name": location_name})
    return redirect("/locations?message=Location added successfully")

@app.route("/add_schedule")
def add_schedule():
    hospital_id=request.args.get("hospital_id")
    return render_template("add_schedules.html",hospital_id=hospital_id)

@app.route("/add_schedule_action", methods=["POST"])
def add_schedule_action():
    hospital_id = request.form.get("hospital_id")
    day = request.form.get("day")
    from_time = request.form.get("consultation_fromtime")
    to_time = request.form.get("consultation_totime")
    status = "Doctor Requested"
    schedule_collection.insert_one({"doctor_id": ObjectId(session.get("doctor_id")),"hospital_id": ObjectId(hospital_id),"status":status,"day": day,"consultation_starttime": from_time,"consultation_endtime": to_time})
    return render_template("doctor_message.html", message="Request Sent Successfully!")


@app.route("/view_schedule")
def view_schedule():
    if session.get("role") != "doctor":
        return redirect("/doctor_login")
    doctor_id = session["doctor_id"]
    schedules = list(schedule_collection.find({"doctor_id": doctor_id}))
    return render_template("view_schedules.html", schedules=schedules,get_hospital_by_hospital_id=get_hospital_by_hospital_id)

def get_hospital_by_hospital_id(hospital_id):
    hospital = hospital_collection.find_one({"_id": ObjectId(hospital_id)})
    return hospital

@app.route("/doctor_requests")
def doctor_requests():
    schedules = []
    if session['role'] == "doctor":
        doctor_id = session.get("doctor_id")
        schedules = list(schedule_collection.find({"doctor_id": ObjectId(doctor_id)}))
    elif session['role'] == "hospital":
        hospital_id = session.get("hospital_id")
        schedules = list(schedule_collection.find({"hospital_id": ObjectId(hospital_id)}))
    return render_template("doctor_requests.html", schedules=schedules,get_hospital_by_hospital_id=get_hospital_by_hospital_id,get_doctor_by_doctor_id=get_doctor_by_doctor_id)


def get_doctor_by_doctor_id(doctor_id):
    doctor = doctor_collection.find_one({"_id": ObjectId(doctor_id)})
    return doctor



@app.route("/view_slots")
def view_slots():
    schedule_id = request.args.get("schedule_id")
    schedule = schedule_collection.find_one({"_id": ObjectId(schedule_id)})
    slots = slots_collection.find({"schedule_id": ObjectId(schedule_id)})
    return render_template("view_slots.html", schedule=schedule, slots=slots)

@app.route("/book_appointment")
def book_appointment():
    schedules = schedule_collection.find({"status": "Request Accepted  By Hospital"})
    return render_template("book_appointment.html",schedules=schedules,get_hospital_by_hospital_id=get_hospital_by_hospital_id,get_doctor_by_doctor_id=get_doctor_by_doctor_id)


@app.route("/book_appointment2")
def book_appointment2():
    schedule_id = request.args.get("schedule_id")
    booking_date = request.args.get("booking_date")

    # Fetch slots

    # If no date selected → use today's date
    if not booking_date:
        booking_date = datetime.date.today().strftime("%Y-%m-%d")

    booking_date_obj = datetime.datetime.strptime(booking_date, "%Y-%m-%d").date()


    day_index = booking_date_obj.weekday()
    weekdays = {
        0: "Monday",
        1: "Tuesday",
        2: "Wednesday",
        3: "Thursday",
        4: "Friday",
        5: "Saturday",
        6: "Sunday"
    }

    today_weekday = weekdays[day_index]
    slots = slots_collection.find({"schedule_id": ObjectId(schedule_id),"day":today_weekday})
    return render_template("book_appointment2.html",get_is_slot_booked=get_is_slot_booked,schedule_id=schedule_id, slots=slots,booking_date=booking_date, today_weekday=today_weekday, day_index=day_index)

def get_is_slot_booked(slot_id,booking_date):
    booking_date = datetime.datetime.strptime(booking_date,"%Y-%m-%d")
    count = appointment_collection.count_documents({"status":'Appointment Booked',"slot_id":ObjectId(slot_id),"booking_date":booking_date})
    if count>0:
        return True
    return False


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")



@app.route("/accept_request")
def accept_request():
    schedule_id = request.args.get("schedule_id")

    return render_template("accept_request.html",schedule_id=schedule_id)

@app.route("/accept_request_action",methods=['post'])
def accept_request_action():
    schedule_id = request.form.get("schedule_id")
    schedule = schedule_collection.find_one({"_id":ObjectId(schedule_id)})
    consultation_fee = request.form.get("consultation_fee")
    query = {'$set': {"status": 'Request Accepted  By Hospital', "consultant_fee": consultation_fee}}
    results = schedule_collection.update_one({"_id": ObjectId(schedule_id)}, query)
    query2 = {"_id": ObjectId(schedule_id)}
    result = schedule_collection.find_one(query2)
    FromTime = result['consultation_starttime']
    ToTime = result['consultation_endtime']
    dd = datetime.date.today()
    dd2 = datetime.date.today()
    date = str(dd) + " " + str(FromTime)
    date2 = str(dd2) + " " + str(ToTime)
    dt = datetime.datetime.strptime(date, '%Y-%m-%d %H:%M')
    dt2 = datetime.datetime.strptime(date2, '%Y-%m-%d %H:%M')
    slot_number = 0
    while dt < dt2:
        from_dt = dt
        to_dt = from_dt + datetime.timedelta(minutes=20)
        dt = to_dt
        fromTime = from_dt.strftime('%H:%M')
        toTime = to_dt.strftime('%H:%M')
        slot_number = slot_number + 1
        query3 = {"fromTime": fromTime, "toTime": toTime, "slot_number": slot_number,
                  "schedule_id": ObjectId(schedule_id),"day":schedule['day']}
        slots_collection.insert_one(query3)

    return render_template("message.html",message="Request Accepted")


@app.route("/confirm_appointment",methods=['post'])
def confirm_appointment():
    slot_id = request.form.get("selected_slot")
    schedule_id = request.form.get("schedule_id")
    booking_date = request.form.get("booking_date")
    if slot_id=="":
        return redirect("book_appointment2?schedule_id="+str(schedule_id)+"&booking_date="+booking_date)
    schedule = schedule_collection.find_one({"_id": ObjectId(schedule_id)})
    return render_template("payment.html",schedule=schedule,slot_id=slot_id,booking_date=booking_date,schedule_id=schedule_id)


@app.route("/confirm_payment",methods=['post'])
def confirm_payment():
    schedule_id = request.form.get("schedule_id")
    slot_id = request.form.get("slot_id")
    booking_date = request.form.get("booking_date")
    card_name = request.form.get("card_name")
    card_number = request.form.get("card_number")
    expiry= request.form.get("expiry")
    cvv=request.form.get("cvv")
    amount=request.form.get("amount")
    patient_id = session.get("patient_id")
    booking_date = datetime.datetime.strptime(booking_date,"%Y-%m-%d")
    a = appointment_collection.insert_one({"schedule_id":ObjectId(schedule_id),"booking_date":booking_date,"slot_id":ObjectId(slot_id),"patient_id": ObjectId(patient_id),"status":"Appointment Booked"})
    appointment_id = a.inserted_id
    payments_collection.insert_one({"appointment_id": appointment_id,"patient_id": ObjectId(patient_id),"status": "Payment Successful","amount": float(amount),"card_name": card_name,"card_number": card_number,"expiry": expiry,"cvv": cvv,"date": datetime.datetime.now()})
    return render_template("message.html",message= "Payment Confirmed & Appointment Booked Successfully")


@app.route("/appointments")
def appointments():
    query = {}
    if session['role']=='patient':
        patient_id = session["patient_id"]
        query = {"patient_id":ObjectId(patient_id)}
    elif session['role']=='hospital':
        hospital_id = session["hospital_id"]
        query={"hospital_id":ObjectId(hospital_id)}
        schedules = schedule_collection.find(query)
        schedule_ids=[]
        for schedule in schedules:
            schedule_ids.append({"schedule_id":ObjectId(schedule['_id'])})
        print(schedule_ids)
        query={"$or":schedule_ids}
        slots=slots_collection.find(query)
        slot_ids=[]
        for slot in slots:
            slot_ids.append({"slot_id":ObjectId(slot['_id'])})
        query={"$or":slot_ids}

    elif session['role']=='doctor':
        doctor_id = session["doctor_id"]
        query = {"doctor_id": ObjectId(doctor_id)}
        schedules = schedule_collection.find(query)
        schedule_ids = []
        for schedule in schedules:
            schedule_ids.append({"schedule_id": ObjectId(schedule['_id'])})
            query = {"$or": schedule_ids}
            slots = slots_collection.find(query)
            slot_ids = []
            for slot in slots:
                slot_ids.append({"slot_id": ObjectId(slot['_id'])})
            query = {"$or": slot_ids}
    appointments = appointment_collection.find(query)
    return render_template("appointments.html", appointments=appointments,get_patient_by_patient_id=get_patient_by_patient_id,get_slot_by_slot_id=get_slot_by_slot_id,get_schedule_by_schedule_id=get_schedule_by_schedule_id,get_hospital_by_hospital_id=get_hospital_by_hospital_id,get_doctor_by_doctor_id=get_doctor_by_doctor_id)

def get_patient_by_patient_id(patient_id):
    patient = patient_collection.find_one({"_id": ObjectId(patient_id)})
    return patient

def get_slot_by_slot_id(slot_id):
    slot = slots_collection.find_one({"_id": ObjectId(slot_id)})
    return slot

def get_schedule_by_schedule_id(schedule_id):
    schedule = schedule_collection.find_one({"_id": ObjectId(schedule_id)})
    return schedule

@app.route("/prescription")
def prescription():
    appointment_id = request.args.get("appointment_id")
    return render_template("prescription.html", appointment_id=appointment_id)

@app.route("/prescription_action", methods=["POST"])
def prescription_action():
    appointment_id = request.form.get("appointment_id")
    prescription_text = request.form.get("prescription")
    date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    prescription_collection.insert_one({"appointment_id": ObjectId(appointment_id),"doctor_id": ObjectId(session["doctor_id"]),"prescription": prescription_text,"date":date})
    appointment_collection.update_one({"_id": ObjectId(appointment_id)},{"$set": {"status": "Prescribed"}})
    return render_template("doctor_message.html", message="Prescription Submitted Successfully!")


@app.route("/view_prescription")
def view_prescription():
    appointment_id = request.args.get("appointment_id")
    appointment = appointment_collection.find_one({"_id": ObjectId(appointment_id)})
    prescription = prescription_collection.find_one({"appointment_id": ObjectId(appointment_id)})
    return render_template("view_prescription.html",appointment=appointment,prescription=prescription)

@app.route("/view_payments")
def view_payments():
    appointment_id = request.args.get("appointment_id")
    payments = list(payments_collection.find({"appointment_id": ObjectId(appointment_id)}))
    return render_template("view_payments.html", payments=payments,appointment_id=appointment_id,get_patient_by_patient_id=get_patient_by_patient_id)


def get_patient_by_patient_id(patient_id):
    patient = patient_collection.find_one({"_id": ObjectId(patient_id)})
    return patient


@app.route("/cancel_appointment")
def cancel_appointment():
    appointment_id = request.args.get("appointment_id")

    query = {"$set": {"status": "Cancelled"}}
    appointment_collection.update_one({"_id": ObjectId(appointment_id)},query)
    return redirect("/appointments")


app.run(debug=True)