import datetime
from itertools import count
from dns.e164 import query
from flask import Flask, request, render_template, redirect, session
import pymysql
from pyexpat.errors import messages
conn = pymysql.connect(host="localhost",user="root",password="Bhavana@123",database="shopping")
cursor = conn.cursor()
app = Flask(__name__)
app.secret_key="hello"
import os
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
PROFILES_PATH = APP_ROOT + "/static/product_image"
@app.route("/")
def index():
    return render_template("index.html")
@app.route("/admin_login")
def admin_login():
    return render_template("admin_login.html")
@app.route("/seller_login")
def seller_login():
    return render_template("seller_login.html")
@app.route("/seller_registration")
def seller_registration():
    cursor.execute("select * from locations")
    locations = cursor.fetchall()
    return render_template("seller_registration.html",locations=locations)
@app.route("/seller_registration_action" , methods=['POST'])
def seller_registration_action():
    seller_name = request.form.get("seller_name")
    phone = request.form.get("phone")
    email= request.form.get("email")
    password = request.form.get("password")
    location_id = request.form.get("location_id")

    count = cursor.execute("select * from sellers where email='"+str(email)+"'")
    if count > 0:
        return render_template("message.html",message="Email exists")

    count = cursor.execute("select * from sellers where phone='"+str(phone)+"'")
    if count > 0:
        return render_template("message.html",message="phone number exists")
    count = cursor.execute("insert into sellers(seller_name,email,phone,password,location_id) values('"+str(seller_name)+"','"+str(email)+"','"+str(phone)+"','"+str(password)+"','"+str(location_id)+"')")
    conn.commit()
    return render_template("admin_message.html",message="Seller registered successfully")
@app.route("/delivery_agency_login")
def delivery_agency_login():
    return render_template("delivery_agency_login.html")
@app.route("/customer_login")
def customer_login():
    return render_template("customer_login.html")
@app.route("/customer_login_action", methods=["POST"])
def customer_login_action():
    email = request.form.get("email")
    password = request.form.get("password")

    count = cursor.execute("select * from customers where email='" + str(email) + "' and password='" + str(password) + "'")
    if count > 0:
        customers = cursor.fetchall()
        session['customer_id']=customers[0][0]
        session['role']="customer"
        return render_template("customer_home.html")
    else:
        return render_template("message.html", message="Invalid login credentials")
@app.route("/customer_registration")
def customer_registration():
    cursor.execute("select * from locations")
    locations = cursor.fetchall()
    return render_template("customer_registration.html",locations=locations)
@app.route("/customer_registration_action",methods=['POST'])
def customer_registration_action():
    name = request.form.get("name")
    phone = request.form.get("phone")
    email = request.form.get("email")
    password = request.form.get("password")
    address = request.form.get("address")
    location_id = request.form.get("location_id")
    count = cursor.execute("select * from customers where email='"+str(email)+"'")
    if count > 0:
        return render_template("message.html",message="Email already exists")
    count = cursor.execute("select * from customers where phone='" + str(phone) + "'")
    if count > 0:
        return render_template("message.html",message="phone already exists")

    count = cursor.execute("insert into customers(customer_name,phone,email,password,address,location_id) values('"+str(name)+"','"+str(phone)+"','"+str(email)+"','"+str(password)+"','"+str(address)+"','"+str(location_id)+"')")
    conn.commit()
    return render_template("message.html",message="Customer registered successfully")
admin_username = "admin"
admin_password = "admin"
@app.route("/admin_login_action",methods=["post"])
def admin_login_action():
    username = request.form.get("username")
    password = request.form.get("password")
    if(username==admin_username and password==admin_password):
        return render_template("admin_home.html")
    else:
        return render_template("message.html",message="Invalid credentials")
@app.route("/admin_home")
def admin_home():
    return render_template("admin_home.html")
@app.route("/locations")
def locations():
    cursor.execute("select * from locations")
    locations = cursor.fetchall()
    return render_template("locations.html", locations=locations)
@app.route("/add_location_action",methods=['POST'])
def add_location_action():
    location_name = request.form.get("location_name")
    count = cursor.execute("select * from locations where location_name='"+str(location_name)+"'")
    if count > 0:
        return render_template("admin_message.html",message="Location exists")
    else:
        cursor.execute("insert into locations(location_name) values('"+str(location_name)+"')")
    conn.commit()
    return render_template("admin_message.html", message= "Location added successfully")
@app.route("/view_locations")
def view_locations():
     cursor.execute("select * from locations")
     locations = cursor.fetchall()
     return redirect("/locations.html",locations=locations)
@app.route("/view_sellers")
def view_sellers():
    cursor.execute("select * from sellers")
    sellers = cursor.fetchall()
    return render_template("sellers.html", sellers=sellers)
@app.route("/set_status")
def set_status():
    seller_id = request.args.get("seller_id")
    status = request.args.get("status")
    if(status == "UNVERIFIED"):
        cursor.execute("update sellers set status='VERIFIED' where seller_id='"+str(seller_id)+"'")
    else:
        cursor.execute("update sellers set status='UNVERIFIED' where seller_id='"+str(seller_id)+"'")
    conn.commit()
    return redirect("/view_sellers")
@app.route("/delivery_agency_actions")
def delivery_agency_actions():
    cursor.execute("select * from delivery_agencies")
    delivery_agencies = cursor.fetchall()
    return render_template("delivery_agencies.html",delivery_agencies= delivery_agencies)
@app.route("/add_delivery_agency_actions", methods=['POST'])
def add_delivery_agency_actions():
    agency_name = request.form.get("agency_name")
    phone = request.form.get("phone")
    password = request.form.get("password")

    cursor.execute("insert into delivery_agencies(agency_name,phone,password) values('"+str(agency_name)+"','"+str(phone)+"','"+str(password)+"')")
    conn.commit()
    return render_template("admin_message.html", message= "Delivery agency added successfully")
@app.route("/delivery_agency_login_action", methods=["POST"])
def delivery_agency_login_action():
    agency_name = request.form.get("agency_name")
    password = request.form.get("password")

    count = cursor.execute("select * from delivery_agencies where agency_name = '"+str(agency_name)+"' and password ='"+str(password)+"'")
    if count > 0:
        agencies=cursor.fetchall()
        session['agency_id'] = agencies[0][0]
        session['role'] = "agency"
        return render_template("deliveryagency_home.html")
    else:
        return render_template("message.html", message="Invalid agency name or password")
@app.route("/seller_login_action", methods=["POST"])
def seller_login_action():
    email = request.form.get("email")
    password = request.form.get("password")

    count = cursor.execute("select * from sellers where email='"+str(email)+"' and password='"+str(password)+"'")
    if count > 0:
        sellers = cursor.fetchall()
        if sellers[0][5]=="UNVERIFIED":
            return render_template("message.html", message="You Account is not verified ")
        else:
            session['seller_id'] = sellers[0][0]
            session['role']="seller"
            return redirect("/seller_home")
    else:
        return render_template("message.html", message="Invalid Login Credentials")
@app.route("/seller_home")
def seller_home():
    return render_template("seller_home.html")
@app.route("/categories")
def categories():
    cursor.execute("select * from categories")
    categories = cursor.fetchall()
    return render_template("categories.html", categories=categories)
@app.route("/add_category_action",methods=['POST'])
def add_category_action():
    category_name = request.form.get("category_name")
    count = cursor.execute("select * from categories where category_name='"+str(category_name)+"'")
    if count > 0:
        return render_template("admin_message.html",message="Category exists")
    else:
        cursor.execute("insert into categories(category_name) values('"+str(category_name)+"')")
    conn.commit()
    return render_template("admin_message.html", message= "Category added successfully")
@app.route("/view_categories")
def view_categories():
     cursor.execute("select * from categories")
     categories = cursor.fetchall()
     return redirect("/categories",categories=categories)
@app.route("/sub_categories")
def sub_categories():
    category_id = request.args.get("category_id")

    cursor.execute("select * from categories")
    categories = cursor.fetchall()

    if category_id:
        cursor.execute("select * from sub_categories where category_id = '"+str(category_id)+"'")
    else:
        cursor.execute("select * from sub_categories")

    sub_categories = cursor.fetchall()

    return render_template("sub_categories.html",category_id=category_id,str=str,categories=categories,sub_categories=sub_categories,get_category_id_by_sub_category=get_category_id_by_sub_category)


@app.route("/add_sub_category_action",methods=['POST'])
def add_sub_category_action():
    category_id  = request.form.get("category_id")
    sub_category_name = request.form.get("sub_category_name")
    count = cursor.execute("select * from sub_categories where sub_category_name='"+str(sub_category_name)+"'")
    if count > 0:
        return render_template("admin_message.html",message="Sub Category exists")
    else:
        cursor.execute("insert into sub_categories(sub_category_name,category_id) values('"+str(sub_category_name)+"','"+str(category_id)+"')")
    conn.commit()
    return render_template("admin_message.html", message= "Sub Category added successfully")
@app.route("/view_sub_categories")
def view_sub_categories():
     cursor.execute("select * from sub_categories")
     sub_categories = cursor.fetchall()
     return redirect("/sub_categories.html",sub_categories=sub_categories)
@app.route("/products")
def products():
    category_id=request.args.get("category_id")
    query=""
    if category_id==None:
        query="select * from sub_categories"
    else:
        query="select * from sub_categories where category_id='"+str(category_id)+"'"
    cursor.execute(query)
    sub_categories = cursor.fetchall()
    cursor.execute("select * from sellers")
    sellers = cursor.fetchall()
    cursor.execute("select * from products")
    products = cursor.fetchall()
    cursor.execute("select * from categories")
    categories = cursor.fetchall()
    return render_template("add_product.html", sub_categories=sub_categories, sellers=sellers,products=products,categories=categories)


@app.route("/add_product_action", methods=["POST"])
def add_product_action():
    product_name = request.form.get("product_name")
    description = request.form.get("description")
    price = request.form.get("price")
    quantity = request.form.get("quantity")
    sub_category_id = request.form.get("sub_category_id")
    seller_id = session.get("seller_id")
    if not seller_id:
        return render_template("seller_message.html", seller_message="Seller not logged in")

    count=cursor.execute("select * from products where product_name='"+str(product_name)+"'")
    if count>0:
        return render_template("seller_message.html",seller_message="product exists")
    product_image = request.files.get("product_image")
    path = PROFILES_PATH + "/" + product_image.filename
    product_image.save(path)
    query = "insert into products(product_name, description, price, quantity, product_image,sub_category_id,seller_id) values ('"+str(product_name)+"','"+str(description)+"','"+str(price)+"','"+str(quantity)+"','"+str(product_image.filename)+"','"+str(sub_category_id)+"','"+str(seller_id)+"')"
    cursor.execute(query)
    conn.commit()
    return render_template("seller_message.html", seller_message="Product added successfully")
@app.route("/view_products")
def view_products():
    keyword=request.args.get("keyword")
    if keyword==None:
        keyword=""
    if session['role']=='seller':
        seller_id = session['seller_id']
        query="select * from products where seller_id='"+str(seller_id)+"' and  product_name like '%"+str(keyword)+"%'"
        cursor.execute(query)
    else:
        query="select * from products where product_name like '%"+str(keyword)+"%'"
        cursor.execute(query)
    products = cursor.fetchall()
    return render_template("/view_products.html",products=products)


@app.route("/view_products2")
def view_products2():
    seller_id = request.args.get("seller_id")
    category_id = request.args.get("category_id")
    sub_category_id = request.args.get("sub_category_id")
    product_name = request.args.get("product_name")
    avg_rating=request.args.get("avg_rating")
    if seller_id==None:
        seller_id=""
    if category_id==None:
        category_id=""
    if sub_category_id==None:
        sub_category_id=""
    if product_name==None:
        product_name=""
    if seller_id=="" and category_id=="" and sub_category_id=="":
        sql="select * from products where product_name like '%"+str(product_name)+"%'"
    elif seller_id=="" and category_id=="" and sub_category_id!="":
        sql="select * from products where sub_category_id='"+str(sub_category_id)+"' and product_name like '%"+str(product_name)+"%'"
    elif seller_id=="" and category_id!="" and sub_category_id=="":
        sql="select * from products where sub_category_id in(select sub_category_id from sub_categories where category_id='"+str(category_id)+"') and product_name like '%"+str(product_name)+"%'"
    elif seller_id=="" and category_id!="" and sub_category_id!="":
        sql="select * from products where sub_category_id='"+str(sub_category_id)+"' and product_name like '%"+str(product_name)+"%'"
    elif seller_id!="" and category_id=="" and sub_category_id=="":
        sql="select * from products where seller_id='"+str(seller_id)+"' and product_name like '%"+str(product_name)+"%'"
    elif seller_id!="" and category_id=="" and sub_category_id!="":
        sql="select * from products where seller_id='"+str(seller_id)+"' and sub_category_id='"+str(sub_category_id)+"' and product_name like '%"+str(product_name)+"%'"
    elif seller_id!="" and category_id!="" and sub_category_id=="":
        sql="select * from products where seller_id='"+str(seller_id)+"' and sub_category_id in(select sub_category_id from sub_categories where category_id='"+str(category_id)+"') and product_name like '%"+str(product_name)+"%'"
    elif seller_id!="" and category_id!="" and sub_category_id!="":
        sql="select * from products where seller_id='"+str(seller_id)+"'  and sub_category_id='"+str(sub_category_id)+"' and product_name like '%"+str(product_name)+"%'"
    cursor.execute(sql)
    products = cursor.fetchall()
    cursor.execute("select * from sellers")
    sellers = cursor.fetchall()
    cursor.execute("select * from categories")
    categories = cursor.fetchall()
    cursor.execute("select * from sub_categories")
    sub_categories = cursor.fetchall()
    return render_template("view_products2.html",avg_rating=avg_rating,product_name=product_name,category_id=category_id,sub_category_id=sub_category_id,str=str,seller_id=seller_id, sellers=sellers,products=products,categories=categories,sub_categories=sub_categories,get_average_rating_by_product_id=get_average_rating_by_product_id)







@app.route("/update_product_action", methods=["POST"])
def update_product_action():
    product_id = request.form.get("product_id")
    product_name = request.form.get("product_name")
    description = request.form.get("description")
    price = request.form.get("price")
    quantity = request.form.get("quantity")
    sub_category_id = request.form.get("sub_category_id")
    seller_id = session.get("seller_id")

    product_image = request.files.get("product_image")
    if product_image and product_image.filename != "":
        path = PROFILES_PATH + "/" + product_image.filename
        product_image.save(path)
        cursor.execute("update products set product_name='"+str(product_name)+"',description='"+str(description)+"',price='"+str(price)+"',quantity='"+str(quantity)+"' where product_id='"+str(product_id)+"'" )
    else:
        cursor.execute("update products set product_name='"+str(product_name)+"',description='"+str(description)+"',price='"+str(price)+"',quantity='"+str(quantity)+"',sub_category_id='"+str(sub_category_id)+"',product_id='"+str(product_id)+"' where product_id='"+str(product_id)+"'")

    conn.commit()
    return render_template("seller_message.html", seller_message="Product updated successfully")


@app.route("/edit_product")
def edit_product():
    product_id = request.args.get("product_id")
    cursor.execute("select * from products where product_id = '"+str(product_id)+"'")
    product = cursor.fetchone()
    cursor.execute("select * from sub_categories")
    sub_categories = cursor.fetchall()
    return render_template("edit_product.html", product=product, sub_categories=sub_categories)

@app.route("/customer_home")
def customer_home():
    return render_template("customer_home.html")


@app.route("/deliveryagency_home")
def deliveryagency_home():
    return render_template("deliveryagency_home.html")

@app.route("/add_to_cart")
def add_to_cart():
    product_id = request.args.get("product_id")
    quantity = request.args.get("quantity")
    order_date = datetime.datetime.now()
    #order_date = order_date.strftime("%Y-%m-%d %I:%M  %p")
    customer_id=session['customer_id']


    cursor.execute("select * from products where product_id='"+str(product_id)+"'")
    product=cursor.fetchone()
    seller_id=product[6]

    count=cursor.execute("select * from orders where customer_id='"+str(customer_id)+"' and  status='cart'")
    if count==0:
        cursor.execute("insert into orders(order_date,status,seller_id,customer_id) values('"+str(order_date)+"','cart','"+str(seller_id)+"','"+str(customer_id)+"')")
        conn.commit()
        order_id=cursor.lastrowid
    else:
        cursor.execute("select * from orders where customer_id='"+str(customer_id)+"' and status='cart'")
        order=cursor.fetchone()
        order_id=order[0]

    count2=cursor.execute("select * from order_items where product_id='"+str(product_id)+"' and order_id='"+str(order_id)+"'")
    if count2==0:
        cursor.execute("insert into order_items(quantity,order_id,product_id) values('"+str(quantity)+"','"+str(order_id)+"','"+str(product_id)+"')")
        conn.commit()
        return render_template("customer_message.html",message="Product Added to Cart")
    else:
        cursor.execute("select * from order_items where product_id='"+str(product_id)+"' and order_id='"+str(order_id)+"'")
        order_item=cursor.fetchone()
        quantity=int(order_item[1] + int(quantity))
        cursor.execute("update order_items set quantity='"+str(quantity)+"' where order_id='"+str(order_id)+"' and product_id='"+str(product_id)+"'")
        conn.commit()
        return render_template("customer_message.html",message="Product updated into Cart")




@app.route("/cart")
def cart():
    customer_id=session['customer_id']
    cursor.execute("select * from orders where customer_id='"+str(customer_id)+"' and status='cart' ")
    orders=cursor.fetchall()
    return render_template("/cart.html",orders=orders,get_order_id_by_order_items=get_order_id_by_order_items,get_product_id_by_order_items=get_product_id_by_order_items,float=float)


def get_order_id_by_order_items(order_id):
    cursor.execute("select * from order_items where order_id = '"+str(order_id)+"'")
    order_items = cursor.fetchall()
    return order_items


def get_product_id_by_order_items(product_id):
    cursor.execute("select * from products where product_id='"+str(product_id)+"'")
    product = cursor.fetchone()
    return product

@app.route("/order_now")
def order_now():
    order_id=request.args.get("order_id")
    order_type=request.args.get("order_type")
    total_price=request.args.get("total_price")
    return render_template("payment.html",order_id=order_id,order_type=order_type,total_price=total_price)

@app.route("/payment_action", methods=['post'])
def payment_action():
    customer_id=session['customer_id']
    total_price = request.form.get("total_price")
    order_id = request.form.get("order_id")
    order_type = request.form.get("order_type")
    card_type = request.form.get("card_type")
    holder_name = request.form.get("holder_name")
    card_number = request.form.get("card_number")
    cvv = request.form.get("cvv")
    expiry_date = request.form.get("expiry_date")
    payment_date=datetime.datetime.now()

    cursor.execute("insert into payments(customer_id,total_amount,order_id,card_type,holder_name,card_number,cvv,expiry_date,payment_date,payment_status) values('"+str(customer_id)+"','"+str(total_price)+"','"+str(order_id)+"','"+str(card_type)+"','"+str(holder_name)+"','"+str(card_number)+"','"+str(cvv)+"','"+str(expiry_date)+"','"+str(payment_date)+"','Payment Successfull')")

    cursor.execute("update orders set status='Ordered', order_type='"+str(order_type)+"', total_amount='"+str(total_price)+"' where order_id='"+str(order_id)+"'")
    conn.commit()
    return render_template("customer_message.html", message="payment done successfully")





@app.route("/remove")
def remove():
    order_id=request.args.get("order_id")
    order_item_id=request.args.get("order_item_id")
    cursor.execute("delete from order_items where order_item_id='"+str(order_item_id)+"'")
    conn.commit()
    count=cursor.execute("select * from orders where order_id='"+str(order_id)+"'")
    if count==0:
        cursor.execute("delete from orders where order_id='"+str(order_id)+"'")
        conn.commit()
    return redirect("/cart")

@app.route("/view_orders")
def view_orders():
    view_type = request.args.get("view_type")
    cursor.execute("select * from delivery_agencies ")
    delivery_agencies = cursor.fetchall()
    if session['role'] == "customer":
        customer_id = session['customer_id']
        if view_type=='view_orders':
            cursor.execute("select * from orders where customer_id='" + str(customer_id) + "' and status='Ordered' ")
        if view_type == 'order_processing':
            cursor.execute("select * from orders where customer_id='" + str(customer_id) + "' and status='Order Dispatched' or status='Order in Progress' ")
        if view_type == 'history':
            cursor.execute("select * from orders where customer_id='" + str(customer_id) + "' and status='Order Received' or status='Order Cancelled' ")
    if session['role'] == "seller":
        seller_id = session['seller_id']
        if view_type == 'view_orders':
            cursor.execute("select * from orders where seller_id='" + str(seller_id) + "' and status='Ordered' ")
        if view_type == 'order_processing':
            cursor.execute("select * from orders where seller_id='"+str(seller_id)+"' and status='Order Dispatched'")
        if view_type == 'history':
            cursor.execute("select * from orders where seller_id='"+str(seller_id)+"' and status='Order Received' or status='Order Cancelled' ")
    if session['role'] == "agency":
        agency_id = session['agency_id']
        if view_type == 'view_orders':
            cursor.execute("select * from orders where agency_id='" + str(agency_id) + "' and status='Order Dispatched' ")
        if view_type == 'order_processing':
            cursor.execute("select * from orders where agency_id='" + str(agency_id) + "' and (status='Order Received' or status='Order in Progress')")
        if view_type == 'history':
            cursor.execute("select * from orders where agency_id='" + str(agency_id) + "' and status='Order Delivered'")
    orders = cursor.fetchall()
    return render_template("/view_orders.html", orders=orders, get_order_id_by_order_items=get_order_id_by_order_items,get_product_id_by_order_items=get_product_id_by_order_items, float=float,view_type= view_type,delivery_agencies=delivery_agencies,get_customer_id_by_orders=get_customer_id_by_orders,is_reviewed_by_customer=is_reviewed_by_customer,get_average_rating_by_product_id=get_average_rating_by_product_id)


@app.route("/order_cancel")
def order_cancel():
    order_id = request.args.get("order_id")
    cursor.execute("update orders set status='Order Cancelled' where order_id='"+str(order_id)+"'")
    conn.commit()
    return render_template("customer_message.html",message="Your order cancelled")


@app.route("/view_payments")
def view_payments():
    order_id=request.args.get("order_id")
    if session['role']=='customer':
        customer_id = session['customer_id']
        cursor.execute("select * from payments where order_id='"+str(order_id)+"' and customer_id='"+str(customer_id)+"'")
    else:
        cursor.execute("select * from payments where order_id='"+str(order_id)+"'")
    payments=cursor.fetchall()
    return render_template("/view_payments.html",payments=payments)

@app.route("/set_status2")
def set_status2():
    order_id = request.args.get("order_id")
    status = request.args.get('status')
    order_type = request.args.get('order_type')
    agency_id = request.args.get("agency_id")
    location_id = request.args.get("location_id")
    if order_type and order_type.strip().lower() == 'delivery':
        cursor.execute("update orders set status='"+str(status)+"', agency_id='"+str(agency_id)+"' where order_id='"+str(order_id)+"'")
        cursor.execute("update delivery_agencies set location_id='"+str(location_id)+"' where agency_id='"+str(agency_id)+"'")
        conn.commit()
        if status == 'Order Delivered':
            return redirect('/view_orders?view_type=history')
        else:
            return redirect("/view_orders?view_type=order_processing")
    if status == 'Order Dispatched':
        cursor.execute("update orders set status='"+str(status)+"' where order_id='"+str(order_id)+"'")
        conn.commit()
        return render_template('seller_message.html', message="Order Dispatched")
    if status == 'Order Received':
        cursor.execute("update orders set status='"+str(status)+"' where order_id='"+str(order_id)+"'")
        conn.commit()
        return redirect('/view_orders?view_type=history')
    if status == 'Order in Progress':
        cursor.execute("update orders set status='"+str(status)+"' where order_id='"+str(order_id)+"'")
        conn.commit()
        return redirect('/view_orders?view_type=history')

    if status == 'Order Delivered':
            cursor.execute("update orders set status='" + str(status) + "'  where order_id='" + str(order_id) + "'")
            conn.commit()
            return redirect('/view_orders?view_type=history')



def get_customer_id_by_orders(customer_id):
    cursor.execute("select * from customers where customer_id='"+str(customer_id)+"'")
    customer = cursor.fetchone()
    return customer


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

def get_category_id_by_sub_category(category_id):
    cursor.execute("select * from categories where category_id = '"+str(category_id)+"'")
    category_name = cursor.fetchone()
    return category_name


@app.route("/review")
def review():
    order_item_id=request.args.get("order_item_id")
    order_id=request.args.get("order_id")
    return render_template("review.html", order_id=order_id,order_item_id=order_item_id)


@app.route("/review_action",methods=['post'])
def review_action():
    review_content = request.form.get("review_content")
    rating = request.form.get("rating")
    customer_id = session['customer_id']
    order_item_id=request.form.get("order_item_id")
    cursor.execute("insert into reviews(review_content,rating,customer_id,order_item_id) values('"+str(review_content)+"','"+str(rating)+"','"+str(customer_id)+"','"+str(order_item_id)+"')" )
    conn.commit()
    return render_template("customer_message.html",message="review submitted successfully")

def is_reviewed_by_customer(order_item_id):
    count=cursor.execute("select * from reviews where order_item_id='"+str(order_item_id)+"'")
    if count==0:
        return False
    return True

def get_average_rating_by_product_id(product_id):
    cursor.execute("select avg(rating) from reviews where order_item_id in(select order_item_id from order_items where product_id='"+str(product_id)+"')")
    review = cursor.fetchone()
    return review



app.run(debug=True)